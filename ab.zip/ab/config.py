from datetime import datetime


TELEGRAM_BOT_TOKEN = '7503444990:AAEXOGvPedkEMFqzA7TxWE9E32JKGQm_skc' #7503444990:AAEXOGvPedkEMFqzA7TxWE9E32JKGQm_skc
TELEGRAM_CHAT_ID = '6751002290'


#dev

TELEGRAM_BOT_TOKEN1 = '7572696874:AAGbMOem1wG-Lwc_FjfiFAMHPz-1jCoUNew'
TELEGRAM_CHAT_ID1 = '7269723073'


SCRAPE_INTERVAL = 1800  # 5 minutes in seconds

MEMBERS_DIR = "members"

CHROME_USER_DATA_DIR = "selenium_profile_bot9"  # bot3 should use "selenium_profile_bot+1"


MAX_SERVERS_TO_SCRAPE = 1 # leave as 1 to scrape 1 server

ignored_names = {"Direct Messages"} #" The Currency Cave",


JOINED_AFTER_DATE = datetime(2025, 4, 20) #change to todays date when tested getting notified


same_count_limit = 30

 #85 should be able to scrape 1700+ before stopping, change depending on active users online
#recommend joining similar servers on one discrod for use. i.e if two servers usually have 4k online then join them on same acc
