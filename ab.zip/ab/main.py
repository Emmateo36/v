import time
import os
import json
from datetime import datetime
from utils.scraper import create_driver_with_cookies, fetch_server_list, scrape_members_from_server
from utils.storage import ensure_storage, load_servers, save_servers
from utils.telegram import send_telegram_message
from utils.telegram import send_telegram_dev
from utils.cookies import save_cookies, load_cookies  # make sure this handles your cookies
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utils.cookies import is_logged_in

from config import SCRAPE_INTERVAL
from config import JOINED_AFTER_DATE


MEMBERS_DIR = "members"
LOG_FILE = "flagged_users_log.txt"



def check_recent_members():
    flagged_users = []

    for filename in os.listdir(MEMBERS_DIR):
        if filename.endswith(".json"):
            filepath = os.path.join(MEMBERS_DIR, filename)

            try:
                with open(filepath, "r") as f:
                    data = json.load(f)
            except json.JSONDecodeError:
                print(f"⚠️ Failed to read {filename}")
                continue

            updated = False

            for member in data:
                if not member.get("added", False):
                    joined_text = member.get("discord_joined", "")
                    if joined_text:
                        dates = joined_text.split("\n")
                        try:
                            for date_str in dates:
                                date_str = date_str.strip()
                                joined_date = datetime.strptime(date_str, "%b %d, %Y")
                                if joined_date > JOINED_AFTER_DATE:
                                    flagged_users.append({
                                        "username": member.get("username"),
                                        "display_name": member.get("display_name"),
                                        "discord_joined": joined_text,
                                        "server_name": member.get("server_name"),
                                        "roles": member.get("roles", [])
                                    })
                                    member["added"] = True
                                    updated = True
                                    break
                        except Exception as e:
                            print(f"⚠️ Failed to parse join date for {member.get('username')}: {e}")

            if updated:
                try:
                    with open(filepath, "w") as f:
                        json.dump(data, f, indent=2)
                    print(f"✅ Updated file: {filename}")
                except Exception as e:
                    print(f"❌ Failed to save updated {filename}: {e}")

    if flagged_users:
        message = "🕵️ Members who joined after the set date:\n"
        log_lines = []

        for m in flagged_users:
            roles_str = f"\n  Roles: {', '.join(m['roles'])}" if m["roles"] else ""
            entry = f"- {m['username']} ({m['display_name']})\n  Joined: {m['discord_joined']}\n  Server: {m['server_name']}{roles_str}\n"
            message += entry + "\n"
            log_lines.append(entry)

        message += f"📦 Total flagged: {len(flagged_users)}"
        #send_telegram_dev(message)

        # Save to local log file
        with open(LOG_FILE, "a") as log_file:
            log_file.write("\n".join(log_lines))
            log_file.write(f"\n--- End of batch ({len(flagged_users)} users) ---\n\n")
    else:
        print("✅ No new members joined after the cutoff.")



def main():
    ensure_storage()

    while True:
        print("🔁 Starting scrape cycle...")

        try:
            driver = create_driver_with_cookies()
            driver.get("https://discord.com/channels/@me")
            time.sleep(5)

            if not is_logged_in(driver):
                send_telegram_dev("⚠️ Manual login required. Please log in to Discord in the browser for .")
                print("⚠️ Please log in manually in the opened browser.")
                input("🔓 Press Enter here after logging in...")
               
                save_cookies(driver)
                print("✅ Cookies updated after manual login.")
                continue

            new_servers = fetch_server_list(driver)
            save_servers(new_servers)

            if not new_servers:
                print("⚠️ No servers found for Bitbull.")
            else:
                for server in new_servers:
                    scrape_members_from_server(driver, server["id"], server["name"])

        except Exception as e:
            print(f"❌ Scraping failed: {e}")
        finally:
            driver.quit()

        print(f"🕒 Waiting {SCRAPE_INTERVAL} seconds... Checking for new members during this break.")
        check_recent_members()
        print("⏳ Sleep complete. Restarting scraping...\n")
        time.sleep(SCRAPE_INTERVAL)

        

if __name__ == "__main__":
    main()
