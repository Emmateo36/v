import json
import os
from selenium.webdriver.chrome.webdriver import WebDriver

COOKIES_FILE = "cookies.json"


def is_logged_in(driver):
    try:
        current_url = driver.current_url
        if "login" in current_url:
            return False
        return True
    except Exception as e:
        print(f"⚠️ Error checking login status by URL: {e}")
        return False



def save_cookies(driver: WebDriver, path=COOKIES_FILE):
    cookies = driver.get_cookies()
    with open(path, "w") as file:
        json.dump(cookies, file, indent=2)
    print("🍪 Cookies saved to cookies.json")

def load_cookies(driver: WebDriver, path=COOKIES_FILE):
    if not os.path.exists(path):
        print("⚠️ No cookies file found.")
        return

    with open(path, "r") as file:
        cookies = json.load(file)

    for cookie in cookies:
        # If domain key exists, strip it (Discord may reject it otherwise)
        cookie.pop("sameSite", None)
        cookie.pop("expiry", None)
        cookie.pop("domain", None)

        try:
            driver.add_cookie(cookie)
        except Exception as e:
            print(f"❌ Error adding cookie: {e}")
    print("✅ Cookies loaded into session")
