# utils/storage.py

import os
import json

SERVER_FILE = "storage/servers.json"
MEMBERS_FOLDER = "storage/members"

def ensure_storage():
    os.makedirs("storage", exist_ok=True)
    os.makedirs(MEMBERS_FOLDER, exist_ok=True)

def load_servers():
    if not os.path.exists(SERVER_FILE):
        return []
    with open(SERVER_FILE, "r") as f:
        return json.load(f)

def save_servers(servers):
    with open(SERVER_FILE, "w") as f:
        json.dump(servers, f, indent=2)

def load_members(server_id):
    path = f"{MEMBERS_FOLDER}/{server_id}.json"
    if not os.path.exists(path):
        return []
    with open(path, "r") as f:
        return json.load(f)

def save_members(server_id, members):
    path = f"{MEMBERS_FOLDER}/{server_id}.json"
    with open(path, "w") as f:
        json.dump(members, f, indent=2)
