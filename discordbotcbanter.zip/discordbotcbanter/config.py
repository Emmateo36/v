from datetime import datetime


TELEGRAM_BOT_TOKEN = '7568678975:AAF2i_085DpcIcSDrO3uQiF5TzDzTFVkH1M' #7568678975:AAF2i_085DpcIcSDrO3uQiF5TzDzTFVkH1M
TELEGRAM_CHAT_ID = '7269723073'


SCRAPE_INTERVAL = 300  # 5 minutes in seconds

MEMBERS_DIR = "members"

CHROME_USER_DATA_DIR = "selenium_profile_bot1"  # bot2 should use "selenium_profile_bot2"


MAX_SERVERS_TO_SCRAPE = 1 # leave as 1 to scrape 1 server

ignored_names = {" Capital Mindset"," The Currency Cave", "Direct Messages", " Comunidade Z1"} #" The Currency Cave",


JOINED_AFTER_DATE = datetime(2025, 3, 31)


same_count_limit = 28 #85 should be able to scrape 1700+ before stopping, change depending on active users online
#recommend joining similar servers on one discrod for use. i.e if two servers usually have 4k online then join them on same acc

#6pm 400+ online