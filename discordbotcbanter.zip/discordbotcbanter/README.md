# Discord User Monitor Bot

## Setup

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Edit `config.py` with your Telegram bot info and Discord cookies.

3. Run the bot:
```
python main.py
```