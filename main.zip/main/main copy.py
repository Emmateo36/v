from discum import Client
from datetime import datetime
import requests

#from telegram import Bot

DISCORD_USER_TOKEN = "ODY5MjgxNjM2ODQyMzU2NzY3.G-M2s1.8C3NIlv5j5Q5bWoRLs0WgfV2wTmpatCTT9mt7k"

TELEGRAM_BOT_TOKEN = '7568678975:AAF2i_085DpcIcSDrO3uQiF5TzDzTFVkH1M' #7568678975:AAF2i_085DpcIcSDrO3uQiF5TzDzTFVkH1M
TELEGRAM_CHAT_ID = '7269723073'

# Initialize clients
client = Client(token=DISCORD_USER_TOKEN, log=False)
#telegram_bot = Bot(token=TELEGRAM_BOT_TOKEN)

LOG_FILE = "joined_members.json"

 #def send_to_telegram(text): telegram_bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=text)



def log_member(data):
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r") as f:
            members = json.load(f)
    else:
        members = []

    members.append(data)

    with open(LOG_FILE, "w") as f:
        json.dump(members, f, indent=2)



def send_to_telegram(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    data = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "parse_mode": "Markdown"  # Optional: for bold/italic support
    }
    try:
        response = requests.post(url, data=data)
        response.raise_for_status()  # Raise error for bad responses
    except Exception as e:
        print(f"❌ Failed to send Telegram message: {e}")




@client.gateway.command
def on_event(resp):
    if resp.event.ready_supplemental:
        print("✅ Connected!")
        send_to_telegram("✅ Connected to the Boss!")

    if resp.raw and resp.raw.get("t") == "GUILD_MEMBER_ADD":
        print("📦 Event Type:", resp.raw.get("t"))  # Log every incoming event
        data = resp.parsed.auto()
        user = data['user']
        username = f"{user['username']}#{user['discriminator']}"
        user_id = user['id']
        guild_id = data['guild_id']
        joined_at = data['joined_at']
        joined_date = datetime.fromisoformat(joined_at.replace("Z", "+00:00")).strftime("%B %d, %Y")

        guild_name = client.gateway.session.guild(guild_id).get("name", "Unknown Server")

        message = (
            f"🆕 New D member joined!\n"
            f"👤 Username: {username}\n"
            f"🆔 ID: {user_id}\n"
            f"📅 Joined At: {joined_date}\n"
            f"🏠 Server: {guild_name}"
        )

        print(message)
        send_to_telegram(message)

        member_data = {
            "username": username,
            "user_id": user_id,
            "joined_at": joined_date,
            "server_id": guild_id,
            "server_name": guild_name,
            "added": False
        }

        log_member(member_data)


#client.gateway.fetchMembers(server_id, channel_id, keep="all", wait=1)
#client.gateway.enableGuildSubscriptions = True
client.gateway.subscribeToGuildEvents(member_data)



# 🔁 Start the gateway
client.gateway.run(auto_reconnect=True)