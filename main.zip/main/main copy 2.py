from discum import Client
#from telegram import Bot

DISCORD_USER_TOKEN = "ODY5MjgxNjM2ODQyMzU2NzY3.G-M2s1.8C3NIlv5j5Q5bWoRLs0WgfV2wTmpatCTT9mt7k"

TELEGRAM_BOT_TOKEN = '7568678975:AAF2i_085DpcIcSDrO3uQiF5TzDzTFVkH1M' #7568678975:AAF2i_085DpcIcSDrO3uQiF5TzDzTFVkH1M
TELEGRAM_CHAT_ID = '7269723073'

# Initialize clients
client = Client(token=DISCORD_USER_TOKEN, log=False)
#telegram_bot = Bot(token=TELEGRAM_BOT_TOKEN)

 #def send_to_telegram(text): telegram_bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=text)


def send_to_telegram(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    data = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "parse_mode": "Markdown"  # Optional: for bold/italic support
    }
    try:
        response = requests.post(url, data=data)
        response.raise_for_status()  # Raise error for bad responses
    except Exception as e:
        print(f"❌ Failed to send Telegram message: {e}")

@client.gateway.command
def on_event(resp):
    if resp.event.ready_supplemental:
        print("✅ Connected!")
        send_to_telegram("✅ Connected to boss!")

    if resp.event.guild_member_add:
        data = resp.parsed.auto()
        user = data['user']
        username = f"{user['username']}#{user['discriminator']}"
        guild_id = data['guild_id']
        joined_at = data['joined_at']

        # You can get server name from session
        guild_name = client.gateway.session.guild(guild_id).get("name", "Unknown Server")

        message = (
            f"🆕 New member joined!\n"
            f"👤 Username: {username}\n"
            f"📅 Joined At: {joined_at}\n"
            f"🏠 Server: {guild_name}"
        )

        print(message)
        send_to_telegram(message)

# Start gateway
client.gateway.run(auto_reconnect=True)
