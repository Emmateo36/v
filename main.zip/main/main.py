import discord
import requests
import json
import os
from datetime import datetime
from config import DISCORD_USER_TOKEN, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, SKIPPED_GUILD_IDS, FLAG_KEYWORDS

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
client = discord.Client(intents=intents)

LOG_FILE = "joined_members.json"

def send_to_telegram(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    data = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "parse_mode": "Markdown"
    }
    try:
        requests.post(url, data=data)
    except Exception as e:
        print(f"❌ Telegram error: {e}")

def log_member(data):
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r") as f:
            members = json.load(f)
    else:
        members = []
    members.append(data)
    with open(LOG_FILE, "w") as f:
        json.dump(members, f, indent=2)

@client.event
async def on_ready():
    print(f"✅ Logged in as {client.user}")
    send_to_telegram("✅ Connected to the Boss!")

@client.event
async def on_member_join(member):
    guild_id = str(member.guild.id)
    if guild_id in SKIPPED_GUILD_IDS:
        print(f"⛔ Skipping server {member.guild.name}")
        return

    username = str(member)
    joined_date = member.joined_at.strftime("%B %d, %Y") if member.joined_at else "Unknown"
    name_check = f"{member.name} {member.display_name}".lower()

    # Filter
    if any(keyword in name_check for keyword in FLAG_KEYWORDS):
        print(f"⛔ Ignored flagged user: {username}")
        return

    message = (
        f"🆕 New member joined!\n"
        f"👤 Username: {username}\n"
        f"🆔 ID: {member.id}\n"
        f"📅 Joined At: {joined_date}\n"
        f"🏠 Server: {member.guild.name}"
    )
    print(message)
    send_to_telegram(message)

    log_member({
        "username": username,
        "user_id": str(member.id),
        "joined_at": joined_date,
        "server_id": guild_id,
        "server_name": member.guild.name,
        "added": False
    })

client.run(DISCORD_USER_TOKEN, bot=False)
