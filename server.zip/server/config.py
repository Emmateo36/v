#do not forget to remove estra details from messages, 
# update the user token and id and 
# start the right bot based on local or online
#change owner name


#imports 

import time
from datetime import datetime
import random





#skip servers
SKIPPED_GUILD_NAMES = ["GrowthPro Trading", "Smart Investment"] #["Canadian Investors", "El Feudo", "Davos protocol", "Trading Alphas", "Foxian Trading Community", "Hypra", "Glow Node FX", "Stock Market Chat", "The Monetic Group", "Glitches"]  # Server names to skip



#proxy

PROXY_USER = "user-sp7b6i3qpz-sessionduration-1440"
PROXY_PASS = "2enW_1u1vZeX0timKa"
PROXY_HOST = "ng.decodo.com"
PROXY_PORT = "42002"


#PROXY_URL = f"http://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}"

PROXY_URL = "http://user-sp7b6i3qpz-sessionduration-1440:2enW_1u1vZeX0timKa@ng.decodo.com:42002"





#tokens

DISCORD_USER_TOKEN = "" #tre
#MTE4ODM3NDE3MzM1NDA0MTQwNQ.Gqz4OZ.0RuqdTZKqgPFEB4WUJ0MoeyQfj0uNQbiv64FkE




#telegram

TELEGRAM_BOT_TOKEN = '7503444990:AAEXOGvPedkEMFqzA7TxWE9E32JKGQm_skc' #7568678975:AAF2i_085DpcIcSDrO3uQiF5TzDzTFVkH1M
#TELEGRAM_CHAT_ID = '7269723073'

TELEGRAM_CHAT_ID = ["7269723073"]



#dev tokenss: updates
TELEGRAM_BOT_DEV = '7572696874:AAGbMOem1wG-Lwc_FjfiFAMHPz-1jCoUNew' #dev bot
TELEGRAM_CHAT_DEV = '7269723073'


Owner = "Tres" #Tmans



#fillters

FLAG_KEYWORDS = ["fx", "crypto", "trade", "trades", "dev", "webdev", "web3"]

CUTOFF_DATE = datetime(2025, 3, 11)  # You can adjust this date



RESTART_EVERY = random.randint(900, 1200)  # 15-22 minutes

COOLDOWN_SECONDS = random.randint(2, 5)
