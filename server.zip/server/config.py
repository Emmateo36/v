import time
from datetime import datetime
import random

FLAG_KEYWORDS = ["fx", "crypto", "trade", "trades", "dev", "webdev", "web3"]

DISCORD_USER_TOKEN = "MTA5OTA2MTQ2NDcxMjYzMDMzMw.GIGnnD.aCud2IvJs5ziBbDO0JT4btpWGOFaiflQjggHFw" #ventil

TELEGRAM_BOT_TOKEN = '7568678975:AAF2i_085DpcIcSDrO3uQiF5TzDzTFVkH1M' #7568678975:AAF2i_085DpcIcSDrO3uQiF5TzDzTFVkH1M
TELEGRAM_CHAT_ID = '7269723073'



#dev updates
TELEGRAM_BOT_DEV = '7572696874:AAGbMOem1wG-Lwc_FjfiFAMHPz-1jCoUNew' #dev bot
TELEGRAM_CHAT_DEV = '7269723073'



Owner = "Tmans"

CUTOFF_DATE = datetime(2025, 3, 11)  # You can adjust this date

SKIPPED_GUILD_NAMES = ["Swing Trade Pros", "VEROTRADE", "Bullo", "Trading Alphas", "WallStreetBets", "EnsoFi", "Glow Node FX"]  # Server IDs to skip
FLAG_KEYWORDS = ["fx", "trade", "crypto", "dev", "webdev", "web3"] #"fx", "trade", "crypto", "dev", "webdev", "web3"]


RESTART_EVERY = random.randint(900, 1200)  # 15-22 minutes

COOLDOWN_SECONDS = random.randint(2, 5)
