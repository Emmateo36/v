import discord
import requests
import json
import os
import time
import re
import threading
import random
import asyncio
import signal
import sys
from datetime import datetime
import aiohttp
from discord import Client
from config import (
    DISCORD_USER_TOKEN,
    TELEGRAM_BOT_TOKEN,
    TELEGRAM_CHAT_ID,
    SKIPPED_GUILD_NAMES,
    FLAG_KEYWORDS,
    CUTOFF_DATE, RESTART_EVERY, COOLDOWN_SECONDS, Owner, PROXY_URL
)

# Make sure you are using discord.py-self
#client = discord.Client(self_bot=True)

MEMBERS_DIR = "members"
os.makedirs(MEMBERS_DIR, exist_ok=True)


def create_client():
    #connector = aiohttp.ProxyConnector.from_url(PROXY_URL)
    #new_client = discord.Client(connector=connector, self_bot=True)
    


    #new_client = discord.Client(self_bot=True)
    new_client = discord.Client(proxy=PROXY_URL, self_bot=True)


    @new_client.event
    async def on_member_join(member):
        global user_join_count
        user_join_count += 1
        print(f"📈 Total users joined since start: {user_join_count}")

        guild_name = member.guild.name
        guild_id = str(member.guild.id)

        if guild_name in SKIPPED_GUILD_NAMES:
            print(f"⛔ Skipping server: {guild_name}")
        else:
            username = member.name
            display_name = member.display_name or member.name
            joined_date = member.joined_at.strftime("%B %d, %Y") if member.joined_at else "Unknown"
            account_created_dt = get_discord_creation_datetime(member.id)
            account_created_str = account_created_dt.strftime("%B %d, %Y")
            name_check = f"{username} {display_name}".lower()

            is_flagged = any(keyword in name_check for keyword in FLAG_KEYWORDS)
            digit_count = count_digits_in_username(username)

            print(f"\n📌 New member in {member.guild.name}")
            print(f"👤 Username: {username} | Display Name: {display_name} | ID: {member.id}")
            print(f"🔍 Checking for keywords: {'❌ Found' if is_flagged else '✅ Clean'}")
            print(f"🔢 Digits in username: {digit_count}")

            send_conditions_met = False
            if not is_flagged:
                if account_created_dt >= CUTOFF_DATE:
                    send_conditions_met = True
                elif digit_count >= 4:
                    send_conditions_met = True

            sent = False
            if send_conditions_met:
                message = (
                    f"{Owner}🆕 New member joined!\n"
                    f"👤 Username: {username}\n"
                    f"📛 Display Name: {display_name}\n"
                    f"📅 Joined Server: {joined_date}\n"
                    f"📆 Account Created: {account_created_str}\n"
                    f"🏠 Server: {member.guild.name}"
                )
                sent = send_to_telegram(message)
            else:
                print(f"📵 Not sending to Telegram due to filters.")

            log_member(guild_id, {
                "username": username,
                "display_name": display_name,
                "user_id": str(member.id),
                "joined_at": joined_date,
                "account_created": account_created_str,
                "server_id": guild_id,
                "server_name": member.guild.name,
                "added": sent,
                "flagged": is_flagged
            })

    return new_client




# --- Telegram Sender ---
def escape_markdown(text):
    escape_chars = r'\_*[]()~`>#+-=|{}.!'
    return ''.join(f'\\{c}' if c in escape_chars else c for c in text)

def send_to_telegram(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    escaped_text = escape_markdown(text)
    data = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": escaped_text,
        "parse_mode": "MarkdownV2"
    }
    try:
        response = requests.post(url, data=data)
        response.raise_for_status()
        print("✅ Telegram message sent.")
        time.sleep(5)
        return True
    except requests.exceptions.RequestException as e:
        print(f"❌ Telegram error: {e}")
        return False


def send_to_dev(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_DEV}/sendMessage"
    escaped_text = escape_markdown(text)
    data = {
        "chat_id": TELEGRAM_CHAT_DEV,
        "text": escaped_text,
        "parse_mode": "MarkdownV2"
    }
    try:
        response = requests.post(url, data=data)
        response.raise_for_status()
        print("✅ Telegram message sent.")
        time.sleep(5)
        return True
    except requests.exceptions.RequestException as e:
        print(f"❌ Telegram error: {e}")
        return False


# --- Save to File (per-server) ---
def log_member(server_id, data):
    filename = os.path.join(MEMBERS_DIR, f"{server_id}.json")
    if os.path.exists(filename):
        with open(filename, "r") as f:
            members = json.load(f)
    else:
        members = []
    members.append(data)
    with open(filename, "w") as f:
        json.dump(members, f, indent=2)
    print(f"📁 Member logged for server {server_id}: {data['username']}")

# --- Get Discord Account Creation Date from Snowflake ---
def get_discord_creation_datetime(user_id):
    discord_epoch = 1420070400000
    timestamp = ((int(user_id) >> 22) + discord_epoch) / 1000
    return datetime.utcfromtimestamp(timestamp)

# --- Helper to count digits in username ---
def count_digits_in_username(username):
    return len(re.findall(r'\d', username))

# --- Counter and Threshold ---
user_join_count = 0
disconnect_trigger = random.randint(1046, 1049)


# Global flag for clean exit
restart_requested = False

def timed_restart(client):
    global restart_requested
    remaining = RESTART_EVERY
    while remaining > 0 and not restart_requested:
        print(f"⏳ Restarting in {remaining} seconds...", end='\r')
        time.sleep(1)
        remaining -= 1
    
    if not restart_requested:
        print("\n🕒 Time's up. Restarting bot...")

        time.sleep(1)
        os.execv(sys.executable, ['python'] + sys.argv)  # Restart script completely
        #os.kill(os.getpid(), signal.SIGINT)  # Simulate Ctrl+C



while True:
    print("🚀 Starting bot...")
    send_to_dev(f"🚀 Starting...{Owner}")
    # Make a new bot with fresh event bindings
    client = create_client()

    try:
                 # Start timer thread
        threading.Thread(target=timed_restart, args=(client,), daemon=True).start()
       
        client.run(DISCORD_USER_TOKEN)

    except Exception as e:
        print(f"🔥 Bot crashed: {e}")
        send_to_dev(f"🔥{Owner} Bot crashed: {e}")
        os.execv(sys.executable, ['python'] + sys.argv)  # Restart script completely
        

    print("🛌 Sleeping briefly before restart...")
    time.sleep(COOLDOWN_SECONDS)

