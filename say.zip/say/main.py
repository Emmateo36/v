#write date filter for date joined disc to send dm, set to 2015 can adjust later if needed

import discord
import requests
import json
import os
import time
from datetime import datetime
from config import (
    DISCORD_USER_TOKEN,
    TELEGRAM_BOT_TOKEN,
    TELEGRAM_CHAT_ID,
    SKIPPED_GUILD_NAMES,
    FLAG_KEYWORDS
)

client = discord.Client(self_bot=True)

MEMBERS_DIR = "members"
os.makedirs(MEMBERS_DIR, exist_ok=True)

# --- Telegram Sender ---
def send_to_telegram(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    data = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "parse_mode": "Markdown"
    }
    try:
        response = requests.post(url, data=data)
        response.raise_for_status()
        print("✅ Telegram message sent.")
        time.sleep(5)  # Prevent rate-limiting
        return True
    except requests.exceptions.RequestException as e:
        print(f"❌ Telegram error: {e}")
        return False

# --- Save to File (per-server) ---
def log_member(server_id, data):
    filename = os.path.join(MEMBERS_DIR, f"{server_id}.json")
    if os.path.exists(filename):
        with open(filename, "r") as f:
            members = json.load(f)
    else:
        members = []
    members.append(data)
    with open(filename, "w") as f:
        json.dump(members, f, indent=2)
    print(f"📁 Member logged for server {server_id}: {data['username']}")

# --- Get Discord Account Creation Date from Snowflake ---
def get_discord_creation_date(user_id):
    discord_epoch = 1420070400000
    timestamp = ((int(user_id) >> 22) + discord_epoch) / 1000
    return datetime.utcfromtimestamp(timestamp).strftime("%B %d, %Y")

# --- Events ---
@client.event
async def on_ready():
    print(f"\n✅ Logged in as {client.user}")
    send_to_telegram("✅ Your bot is active Boss!")

@client.event
async def on_member_join(member):
    guild_name = member.guild.name
    guild_id = str(member.guild.id)  # ✅ Add this back
    if guild_name in SKIPPED_GUILD_NAMES:
        print(f"⛔ Skipping server: {guild_name}")
        return

    username = member.name
    display_name = member.display_name or member.name
    joined_date = member.joined_at.strftime("%B %d, %Y") if member.joined_at else "Unknown"
    account_created = get_discord_creation_date(member.id)
    name_check = f"{member.name} {display_name}".lower()

    is_flagged = any(keyword in name_check for keyword in FLAG_KEYWORDS)

    print(f"\n📌 New member in {member.guild.name}")
    print(f"👤 Username: {username} | Display Name: {display_name} | ID: {member.id}")
    #print(f"📅 Joined Server: {joined_date} | 📆 Created: {account_created}")
    print(f"🔍 Checking for keywords: {'❌ Found' if is_flagged else '✅ Clean'}")

    sent = False
    if not is_flagged:
        message = (
            f"🆕 New member joined!\n"
            f"👤 Username: {username}\n"
            f"📛 Display Name: {display_name}\n"
            f"🏠 Server: {member.guild.name}"
        )
        sent = send_to_telegram(message)
    else:
        print(f"⛔ Flagged member (only logged): {username} / {display_name}")

    log_member(guild_id, {
        "username": username,
        "display_name": display_name,
        "user_id": str(member.id),
        "joined_at": joined_date,
        "account_created": account_created,
        "server_id": guild_id,
        "server_name": member.guild.name,
        "added": sent,
        "flagged": is_flagged
    })

# --- Run Bot ---
client.run(DISCORD_USER_TOKEN)
