FLAG_KEYWORDS = ["fx", "crypto", "trade", "trades", "dev", "webdev", "web3"]

DISCORD_USER_TOKEN = "OTgyMDkxODgyNDkyNDg5Nzk4.Gtz645.hkrY3sO6pBy4jfIi5wobrmrIMwWy8YhE1FaFz8" #ventil

TELEGRAM_BOT_TOKEN = '7572696874:AAGbMOem1wG-Lwc_FjfiFAMHPz-1jCoUNew' #7568678975:AAF2i_085DpcIcSDrO3uQiF5TzDzTFVkH1M
TELEGRAM_CHAT_ID = '6751002290'


SKIPPED_GUILD_NAMES = []  # Server IDs to skip
FLAG_KEYWORDS = [] #"fx", "trade", "crypto", "dev", "webdev", "web3"]
